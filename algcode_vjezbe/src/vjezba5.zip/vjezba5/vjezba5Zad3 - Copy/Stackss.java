package vjezba5Zad3;

import java.util.Stack;

public class Stackss {

    Stack<String> stog1;
    Stack<String> stog2;
    public Stackss(Stack<String> stog1, Stack<String> stog2) {
        this.stog1 = stog1;
        this.stog2 = stog2;
    }
    public Stack<String> getStog1() {
        return stog1;
    }
    public Stack<String> getStog2() {
        return stog2;
    }
}
